import React from "react";
import Navbar from "./Navbar";

export default function About() {
  return (
    <div>
      <Navbar />
      <br />
      <br />
      <br />
      <h1 className="text-center text-info">
        This feature is still in development, please come back later!
      </h1>
    </div>
  );
}
