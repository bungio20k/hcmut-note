import Navbar from "./Navbar";

export default function Tutorial() {
  return (
    <div>
      <Navbar />
      <br />
      <br />
      <br />
      <h1 className="text-center text-info">
        This feature is still in development, please come back later!
      </h1>
    </div>
  );
}
